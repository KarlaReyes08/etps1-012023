package com.ejercicio.login2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class CalculadoraPeso extends AppCompatActivity {

    EditText Peso, Altura;
    TextView tvresultado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calculadora_peso);

        Peso = findViewById(R.id.edtPeso);
        Altura = findViewById(R.id.edtAltura);
        tvresultado=findViewById(R.id.tvResultados);
    }
//dato1 = Double.parseDouble(val1.getText().toString());
// twresultado.setText("El resultado de la suma es: " + String.valueOf(resultado));
//<>
    public void PesoIdeal(View view){
        double peso,altura, resultado;

        peso = Double.parseDouble(Peso.getText().toString());
        altura = Double.parseDouble(Altura.getText().toString());
        resultado = (peso)/ (altura*altura);
        if (resultado < 10.5 ){
            tvresultado.setText("Criticamente Bajo de peso" );
        }
        if (resultado < 15.9 ){
            tvresultado.setText("Severamente Bajo de peso" );
        }
        if (resultado < 18.5 ){
            tvresultado.setText("Bajo de peso");
        }
        if (resultado < 25 ){
            tvresultado.setText("Normal(peso saludable");
        }
        if (resultado < 30 ){
            tvresultado.setText("Sobrepeso");
        }
        if (resultado < 35 ){
            tvresultado.setText("Obesidad Clase 1- Moderadamente Obeso");
        }
        if (resultado < 40 ){
            tvresultado.setText("Obesidad Clase 2- Severamente Obeso");
        }
        if (resultado > 50  ){
            tvresultado.setText("Obesidad Clase 3- Criticamente Obeso ");
        }
    }
}