package com.ejercicio.login2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    //VARIABLES A UTILIZAR
    EditText et1, et2;
    String user = "parcialETps1";
    String pass = "p4rC14#tp$";

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        et1 = findViewById(R.id.edtUser);
        et2= findViewById(R.id.edtPass);

    }

    public void validar (View view)
    {
        String Usuario,Contraseña;
        Usuario = et1.getText().toString();
        Contraseña =et2.getText().toString();

        //CONDICIONES DE VALICIDACION DE USER Y CONTRA
        if (Usuario.length() != 0){
            if (Usuario.equals(user)){
                if (Contraseña.length() != 0){
                    if (Contraseña.equals(pass)){
                        Toast.makeText(this, "DATOS CORRECTOS", Toast.LENGTH_LONG).show();

                        //LLAMANDO A TRAVES DEL INTENTO LA SEGUNDA ACTIVITY
                        Intent i = new Intent(this,CalculadoraPeso.class);
                        startActivity(i);
                    }
                    else{
                        Toast.makeText(this, "Contraseña y usuarios no son correctos", Toast.LENGTH_LONG).show();
                    }
                }
                else{
                    Toast.makeText(this, "No puedes dejar campos vacios", Toast.LENGTH_LONG).show();
                }
            }else{
                Toast.makeText(this, "Contraseña y usuario no son correctos", Toast.LENGTH_LONG).show();
            }
        }
        else{
            Toast.makeText(this, "No puedes dejar campos vacios", Toast.LENGTH_LONG).show();
        }
    }
}